import React from 'react'
import {Text, View, StyleSheet, Button } from 'react-native';
import Contact from './Kontak';

const Home=({navigation}) =>{

 
  return(
  <View> 
    <Text>Aplikasi Daftar Teman</Text>

      <Contact 
        gambar={require("../assets/2130521007.jpg")}
        judul="SILVI SRI"
        telpon="2130521007"/>

        <Button title ='LIHAT'
                  onPress={()=>navigation.navigate('About', {id : "2130521007"})} />

      <Contact 
        gambar={require("../assets/2130521001.jpg")}
        judul="SITI ZAKIYYAH ALKARIMAH"
        telpon="2130521001" />

        <Button title ='LIHAT'
                  onPress={()=>navigation.navigate('About', {id : "2130521001"})} />

    
  </View>
  )
};
export default Home;