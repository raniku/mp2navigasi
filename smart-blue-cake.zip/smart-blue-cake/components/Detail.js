import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
export default function Detail(props) {
    return (
        <View style={styles.container}>
            <Image source={props.gambar} style={styles.img} />
        </View>
    )
}


const styles = StyleSheet.create({
    container: {
        height: 100,
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: 1,
        borderColor: 'blue'
    },
    img: {
        margin: 15,
        width: 100,
        height: 100
    },
    
})