import React from 'react'
import {Text, View, Stylesheet, Button } from 'react-native';
import Detail from './Detail'

const About =({navigation}) => {
  return(
    <View>
    <Text>Detail Informasi</Text>
    <Detail 
        gambar={require("../assets/2130521007.jpg")}/>


    <Button title="HOME" 
      onPress={()=>navigation.navigate('Home')} />
    </View>
  );
};
export default About